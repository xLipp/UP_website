<?php
require_once 'auth_gl.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $serviceId = $_POST["service_id"];

    // Ваш SQL-запрос на удаление услуги из базы данных
    $sql = "DELETE FROM service_user WHERE id_service = $serviceId";

    if ($conn->query($sql) === TRUE) {
        echo "Услуга успешно удалена";
        header('Location: /adm_assemb.php');
    } else {
        echo "Ошибка при удалении услуги: " . $conn->error;
    }
}

// Закрытие соединения с базой данных
$conn->close();
?>