<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="stylesheet" href="css/textarea.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<header>
        <nav align="left" >
            <ul>
                <li><a href="userpage.php"><span>Главная</span></a></li>
                <li><a href="order.php"><span>Оформить заказ</span></a></li>
                <li><a href="help.html"><span>Юр.информация</span></a></li>
                <li><a href="index.html"><span>Выход</span></a></li>
            </ul>
        </nav>
    </header>
    <h1 style="color:#FF8300"><span class="blue">&lt;</span>Мой профиль<span class="blue">&gt;</span></h1>
<table style="margin-left: 200px;margin-top:0;width:80%;" class="container">
<tr>
<th style="background: linear-gradient(#333, #FF8300);color:lightgray">Логин</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Имя</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Фамилия</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Дата рождения</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">номер телефона</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Email</th>
</tr>
<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "klient_database";
        
        // Создание подключения
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Проверка подключения
        if ($conn->connect_error) {
            die("Ошибка подключения к базе данных: " . $conn->connect_error);
        }
        
        // SQL запрос для извлечения данных
        $sql = "SELECT * FROM user_data WHERE login_user='$user_login'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // Вывод данных каждой услуги в виде списка
           
            $row = $result->fetch_assoc(); 
                echo "<tr><td>".$row["login_user"]."</td>";
                echo "<td>" . $row["first_name_user"] . "</td>";
                echo "<td>" . $row["last_name_user"] . "</td>";
                echo "<td>" . $row["birthday_user"] . "</td>";
                echo "<td>" . $row["number_user"] . "</td>";
                echo "<td>" . $row["mail_user"] . "</td>";
                echo"</tr>";
                echo "<br>";
            
        } else {
            echo "Нет данных о услугах.";
        }
        
        // Закрытие соединения с базой данных
        $conn->close();
    
        ?>
</table>
</body>
</html>