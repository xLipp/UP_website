<?php
require_once 'auth_gl.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name_service"];
    $price = $_POST["price_service"];
    $description = $_POST["description_service"];

    // Ваш SQL-запрос на добавление услуги в базу данных
    $sql = "INSERT INTO service_user (name_service, price_service, description_service) VALUES ('$name', '$price', '$description')";
    if ($conn->query($sql) === TRUE) {
        echo "Услуга успешно добавлена";
        header('Location: /adm_assemb.php');
    } else {
        echo "Ошибка: " . $sql . "<br>" . $conn->error;
    }
}

// Закрытие соединения с базой данных
$conn->close();
?>