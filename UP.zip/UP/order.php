<?php
session_start();

// Проверка авторизации
// Подключение к базе данных

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Получение информации о всех видах услуг
$sql = "SELECT * FROM service_user";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Страница оформления заказа</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="stylesheet" href="css/textarea.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<header>
        <nav align="left" >
            <ul>
                <li><a href="userpage.php"><span>Главная</span></a></li>
                <li><a href="order.php"><span>Оформить заказ</span></a></li>
                <li><a href="help.html"><span>Юр.информация</span></a></li>
                <li><a href="index.html"><span>Выход</span></a></li>
            </ul>
        </nav>
    </header>
<h1 style="color:#FF8300"><span class="blue">&lt;</span>Выберите услугу<span class="blue">&gt;</span></h1>
<div class="container" style="min-height: 50vh;">
<form action="process_order.php" method="post" align="center">
       
        <select id="service" name="service"> <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['id_service'] . "'>" . $row['name_service'] . "</option>";
            }
        }
        ?> </select>
       
        <button class="button login_submit" style="background:lightgray" type="submit">
        <span class="button_text">Заказать</span>
      </button>
    </form>
</div>
</body>
</html>
