<?php
session_start();

// Проверка авторизаци

// Подключение к базе данных

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_user=$_SESSION['id_user'];
    $id_order_service = $_POST['service'];

    // Вставка заказа в базу данных
    $sql = "INSERT INTO order_user (id_order_user, id_order_service) VALUES ('$id_user', '$id_order_service')";
    if ($conn->query($sql) === TRUE) {
        echo "Заказ успешно оформлен";
        header('Location: /order.php');
    } else {
        echo "Ошибка при оформлении заказа: " . $conn->error;
    }
}
?>