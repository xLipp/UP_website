<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Обработка запроса поиска пользователя
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login_user = $_POST['login_user'];

    // Запрос для получения информации о пользователе из нескольких таблиц
    $sql = "SELECT  ud.login_user, ud.first_name_user, ud.last_name_user, ud.birthday_user, ud.number_user, ud.mail_user, ou.id_order_service, su.price_service
            FROM user_data ud
            LEFT JOIN order_user ou ON ud.id_user = ou.id_order_user
            LEFT JOIN service_user su ON ou.id_order_service = su.id_service
            WHERE ud.login_user = '$login_user'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Создание PDF
        require_once('TCPDF-main/tcpdf.php'); // Замените 'tcpdf/tcpdf.php' на путь к вашей библиотеке PDF

      // Создание нового документа PDF
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Установка свойств документа
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('PDF Example');
$pdf->SetSubject('Example');

// Устанавливаем отступы
$pdf->SetMargins(15, 15, 15, true);

// Добавляем новую страницу
$pdf->AddPage();

// Установка шрифта
$pdf->SetFont('dejavusans', '', 12, '', true);
        // Отображение информации о пользователе в PDF
        while ($row = $result->fetch_assoc()) {
            $pdf->Write(0, "Логин: " . $row['login_user'] . "\n");
            $pdf->Write(0, "Имя: " . $row['first_name_user'] . "\n");
            $pdf->Write(0, "Фамилия: " . $row['last_name_user'] . "\n");
            $pdf->Write(0, "День рождения: " . $row['birthday_user'] . "\n");
            $pdf->Write(0, "Телефон: " . $row['number_user'] . "\n");
            $pdf->Write(0, "Email: " . $row['mail_user'] . "\n");
            $pdf->Write(0, "ID заказа: " . $row['id_order_service'] . "\n");
            $pdf->Write(0, "Стоимость услуги: " . $row['price_service'] . "\n");
            $pdf->Write(0, "----------------------------------------- "."\n");
        }

        // Генерация PDF файла
        $pdf->Output('user_info.pdf', 'D'); // Скачивание файла

    } else {
        echo "Пользователь не найден";
    }
}

$conn->close();
?>