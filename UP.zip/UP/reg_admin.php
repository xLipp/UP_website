<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Регистрация администратора</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<header>
    <nav>
    <ul>
        <li><a href="adminpage.php"><span>Главная</span></a></li>
        <li><a href="serv_admin.php"><span>Заказы</span></a></li>
                <li><a href="adm_assemb.php"><span>Услуги</span></a></li>
                <li><a href="reg_admin.php"><span>Новый админ</span></a></li>
                <li><a href="index.html"><span>Выйти</span></a></li>
        </ul>
    </nav>
</header>
<div class="container">
  <div class="screen" style="height:70%;">
    <div class="screen_content">
    <form action="php/reg.php" method="post" enctype="multipart/form-data"
    class="login" autocomplete="off">
    <div class="login_field">
    <i class="login_icon fa fa-user"></i>
        <input type="text" id="first_name" class="login_input" placeholder="Имя"
         name="first_name" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-user"></i>
        <input type="text" id="last_name" class="login_input"
         name="last_name" placeholder="Фамилия" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-birthday-cake"></i>
        <input type="date" id="birthday" class="login_input" 
        placeholder="День рождения" name="birthday" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-phone-square"></i>
        <input type="text" id="number" class="login_input"
         placeholder="Телефон" name="number" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-envelope" style="color:#333;"></i>
        <input type="email" class="login_input" placeholder="Email"
         id="email" name="email" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-key" style="color:#333;"></i>
        <input type="text" class="login_input" placeholder="Логин"
         id="login" name="login" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fas fa-lock" style="color:#333;"></i>
        <input type="password" class="login_input" placeholder="Пароль"
         id="password" name="password" required><br><br>
    </div>

    <div class="login_field">
    <i class="login_icon fa fa-picture-o" style="color:#333;"></i>
        <input type="file" сlass="login_input" placeholder="Фото" id="photo" name="photo" accept="image/*" required><br><br>
    </div>

    <button class="button login_submit" type="submit">
          <span class="button_text">Зарегистрировать</span>
          <i class="button_icon fas fa-chevron-right"></i>
        </button>
    </form>
    </div>
  <div class="screen_background">
    <span class="screen_background_shape screen_background_shape4"></span>
    <span class="screen_background_shape screen_background_shape3"></span>
    <span class="screen_background_shape screen_background_shape2"></span>
    <span class="screen_background_shape screen_background_shape1"></span>
  </div>
  </div>
</body>
</html>