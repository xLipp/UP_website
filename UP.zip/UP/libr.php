<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Услуги</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
</head>
<body>
<header>
        <nav>
            <ul>
                <li><a href="index.html"><span>Главная</span></a></li>
                <li><a href="libr.php"><span>Наши услуги</span></a></li>
                <li><a href="help.html"><span>Юр.информация</span></a></li>
                <li><a href="login.html"><span>Вход</span></a></li>
            </ul>
        </nav>
    </header>
<form method="post">
<table style="margin-left: 200px;margin-top:0;width:80%;" class="container">
<tr>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Услуги</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Стоимость услуги(руб)</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">    Описание</th>
</tr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// SQL запрос для извлечения данных
$sql = "SELECT name_service, price_service, description_service FROM service_user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Вывод данных каждой услуги в виде списка
   
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["name_service"] . "</td>";
        echo "<td>" . $row["price_service"] . "</td>";
        echo "<td>" . $row["description_service"] . "</td>";
        echo "</tr>";
    }
    
} else {
    echo "Нет данных о услугах.";
}

// Закрытие соединения с базой данных
$conn->close();
?>
</table>
</form>
</body>
</html>