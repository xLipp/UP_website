
<?php
session_start();

// Проверка авторизации пользователя
if (!isset($_SESSION['user_login'])) {
    header('Location: login.php');
    exit();
}

// Получение данных пользователя из сессии или базы данных
$user_login = $_SESSION['user_login'];

// Подключение к базе данных
require_once 'auth_gl.php';

$sql = "SELECT * FROM user_data WHERE login_user='$user_login'";
$result = $conn->query($sql);

// Отображение информации о пользователе
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Вывод информации о пользователе
    echo "Логин: " . $row['login_user'] . "<br>";
    echo "Имя: " . $row['first_name_user'] . "<br>";
    echo "Фамилия: " . $row['last_name_user'] . "<br>";
    echo "Дата рождения: " . $row['birthday_user'] . "<br>";
    echo "Номер телефона: " . $row['number_user'] . "<br>";
    echo "Email: " . $row['mail_user'] . "<br>";
    
} else {
    echo "Данные пользователя не найдены";
}

$conn->close();
?>