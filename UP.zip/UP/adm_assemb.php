<?php
// Подключение к базе данных (замените значения на свои)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL запрос для получения информации о заказах
$sql = "SELECT order_user.id_order, user_data.first_name_user, user_data.last_name_user, user_data.mail_user, user_data.number_user, service_user.name_service, service_user.price_service
        FROM order_user
        INNER JOIN user_data ON order_user.id_order_user = user_data.id_user
        INNER JOIN service_user ON order_user.id_order_service = service_user.id_service";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заказы</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="stylesheet" href="css/textarea.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
<header>
    <nav>
        <ul>
        <li><a href="adminpage.php"><span>Главная</span></a></li>
        <li><a href="serv_admin.php"><span>Заказы</span></a></li>
                <li><a href="adm_assemb.php"><span>Услуги</span></a></li>
                <li><a href="reg_admin.php"><span>Новый админ</span></a></li>
                <li><a href="index.html"><span>Выйти</span></a></li>
        </ul>
    </nav>
</header>
<!-- Форма добавления услуги -->

<h1 style="color:#FF8300"><span class="blue">&lt;</span>Добавить новую услугу<span class="blue">&gt;</span></h1>
<div class="container" style="min-height: 50vh;">
    <form action="add_service.php" method="post" align="center" autocomplete="off">
        <div class="login_field">
        <input type="text" id="name" class="login_input" placeholder="Название услуги"
        style="width:50%" name="name_service"><br><br>
        </div>
        <div class="login_field">
        <input type="text" class="login_input" placeholder="Стоимость(руб)"
        style="width:50%" id="price" name="price_service"><br><br>
        </div>
        <label for="description" style="color:lightgray">Описание:</label><br>
        <textarea style="background:#333" id="description" name="description_service" rows="4" cols="50"></textarea><br><br>
        <button class="button login_submit" style="background:lightgray" type="submit">
        <span class="button_text">Добавить</span>
      </button>
    </form>
</div>
<br>



<!-- Форма удаления услуги -->

<h1 style="color:#FF8300"><span class="blue">&lt;</span>Удалить услугу<span class="blue">&gt;</span></h1>
<div class="container" style="min-height: 50vh;">
<form action="delete_service.php" method="post" align="center" autocomplete="off">
        <div class="login_field">
        <input type="text" class="login_input" placeholder="ID"
        style="width:50%" id="deleteId" name="service_id"><br><br>
        </div>
        <button class="button login_submit" style="background:lightgray" type="submit">
        <span class="button_text">Удалить</span>
      </button>
    </form>
</div>
    <table style="margin-left: 200px;margin-top:0;width:80%;" class="container">
<tr>
<th style="background: linear-gradient(#333, #FF8300);color:lightgray">Номер услуги (id)</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Услуги</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Стоимость услуги(руб)</th>
  <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Описание</th>
</tr>
<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "klient_database";
        
        // Создание подключения
        $conn = new mysqli($servername, $username, $password, $dbname);
        
        // Проверка подключения
        if ($conn->connect_error) {
            die("Ошибка подключения к базе данных: " . $conn->connect_error);
        }
        
        // SQL запрос для извлечения данных
        $sql = "SELECT id_service, name_service, price_service, description_service FROM service_user";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // Вывод данных каждой услуги в виде списка
           
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["id_service"]."</td>";
                echo "<td>" . $row["name_service"] . "</td>";
                echo "<td>" . $row["price_service"] . "</td>";
                echo "<td>" . $row["description_service"] . "</td></tr>";
                echo "<br>";
            }
            
        } else {
            echo "Нет данных о услугах.";
        }
        
        // Закрытие соединения с базой данных
        $conn->close();
    
        ?>
</table>
</body>
</html>