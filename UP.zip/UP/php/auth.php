<?php 
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

    $username =$_POST["login"];
    $password = $_POST["password"];

    // Поиск пользователя в таблице пользователей
    $user_query = "SELECT * FROM user_data WHERE login_user = '$username' AND pass_user = '$password'";
    $user_result = $conn->query($user_query);
    if ($user_result->num_rows > 0) {
        // Пользователь найден, перенаправление на страницу пользователя
        header("Location: userpage.php");
        exit();
    } else {
    // Поиск пользователя в таблице администраторов
    $admin_query = "SELECT * FROM admin_user WHERE login_admin = '$username' AND pass_admin = '$password'";
    $admin_result = $conn->query($admin_query);

    if ($admin_result->num_rows > 0) {
        // Администратор найден, перенаправление на страницу администратора
        header("Location: adminpage.php");
        exit();
    } else {
        // Неверный логин или пароль
        echo "Invalid username or password. Please try again.";
    }
}

$conn->close();
?>