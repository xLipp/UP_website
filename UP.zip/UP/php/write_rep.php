<?php
// Подключение к базе данных (замените значения на свои)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$text = $_POST['rep'];


// SQL запрос для регистрации администратора
$sql = "INSERT INTO complain (text) 
        VALUES ('$text')";

if ($conn->query($sql) === TRUE) {
    echo "Admin registered successfully";
    header('Location: /help.html');
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>