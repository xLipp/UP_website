<?php
// Подключение к базе данных (замените значения на свои)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из формы
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$birthday = $_POST['birthday'];
$number = $_POST['number'];
$email = $_POST['email'];
$login = $_POST['login'];
$password = md5( $_POST['password']);
if(!empty($_FILES['photo']['tmp_name'])){
$photo = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
}

// SQL запрос для регистрации администратора
$sql = "INSERT INTO user_data (first_name_user, last_name_user, birthday_user, number_user, mail_user, login_user, pass_user, photo_user) 
        VALUES ('$first_name', '$last_name', '$birthday', '$number', '$email', '$login', '$password', '$photo')";

if ($conn->query($sql) === TRUE) {
    echo "Admin registered successfully";
    header('Location: /reg_admin.php');
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>