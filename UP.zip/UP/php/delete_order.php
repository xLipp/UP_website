<?php
// Подключение к базе данных (замените значения на свои)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение ID заказа из параметра запроса
if (isset($_GET['id'])) {
    $id_order = $_GET['id'];

    // SQL запрос для удаления заказа
    $sql = "DELETE FROM order_user WHERE id_order = $id_order";

    if ($conn->query($sql) === TRUE) {
        echo "Order deleted successfully";
    } else {
        echo "Error deleting order: " . $conn->error;
    }
} else {
    echo "No order ID specified";
}

$conn->close();
?>