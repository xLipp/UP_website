<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка подключения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из POST запроса (замените настройки на свои)
$user_login = $_POST['user_login'];
$user_password = $_POST['user_password'];


// Поиск пользователя в базе данных
$user_query = "SELECT * FROM user_data WHERE login_user='$user_login' AND pass_user='$user_password'";
$result = $conn->query($user_query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Проверка пароля
    if (password_verify($user_password, $row['user_password'])) {
        // Создание токена
        $secret_key = "key"; // Замените на свой секретный ключ
        $payload = array(
            "user_id" => $row['id'],
            "username" => $row['username']
        );
        require_once('/php-jwt-main/src/JWT.php');
        $jwt = JWT::encode($payload, $secret_key);
        
        // Отправка токена в ответе
        echo json_encode(array("jwt" => $jwt));
    } else { $admin_query = "SELECT * FROM admin_user WHERE login_admin='$user_login' AND pass_admin='$user_password'";
        $admin_result = $conn->query($admin_query);
    
        if ($admin_result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($user_password, $row['pass_admin'])) {
                // Создание токена
                $secret_key = "ваш_секретный_ключ"; // Замените на свой секретный ключ
                $payload = array(
                    "user_id" => $row['id'],
                    "username" => $row['username']
                );
                require_once('/php-jwt-main/src/JWT.php');
                $jwt = JWT::encode($payload, $secret_key);
                
                // Отправка токена в ответе
                echo json_encode(array("jwt" => $jwt));
    }
} else {
    echo "Пользователь не найден";
}
    }
}

$conn->close();
?>