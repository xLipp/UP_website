<?php
// Подключение к базе данных (замените значения на свои)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "klient_database";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL запрос для получения информации о заказах
$sql = "SELECT order_user.id_order, user_data.first_name_user, user_data.last_name_user, user_data.mail_user, user_data.number_user, user_data.login_user, service_user.name_service, service_user.price_service
        FROM order_user
        INNER JOIN user_data ON order_user.id_order_user = user_data.id_user
        INNER JOIN service_user ON order_user.id_order_service = service_user.id_service";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заказы</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/log.css">
    <link rel="stylesheet" href="css/textarea.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
    <nav>
        <ul>
        <li><a href="adminpage.php"><span>Главная</span></a></li>
        <li><a href="serv_admin.php"><span>Заказы</span></a></li>
                <li><a href="adm_assemb.php"><span>Услуги</span></a></li>
                <li><a href="reg_admin.php"><span>Новый админ</span></a></li>
                <li><a href="index.html"><span>Выйти</span></a></li>
        </ul>
    </nav>
</header>
<h1 style="color:#FF8300"><span class="blue">&lt;</span>Распечатать заказ<span class="blue">&gt;</span></h1>
<div class="container" style="min-height: 30vh;">
    <form action="search_users.php" align="center" autocomplete="off" method="POST">
    <div class="login_field">
        <input type="text" id="login_user" class="login_input" placeholder="Логин пользователя"
        style="width:90%" name="login_user">
    </div>
    <button class="button login_submit" style="background:lightgray" type="submit">
        <span class="button_text">Начать</span>
    </form>
</div>
    <table style="margin-left: 200px;margin-top:0;width:80%;" class="container">
        <tr>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Номер заказа:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Имя:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Фамилия:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Логин:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Почта:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Номер телефона:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Имя услуги:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Стоимость:</th>
            <th style="background: linear-gradient(#333, #FF8300);color:lightgray">Удалить:</th>
        
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id_order'] . "</td>";
                echo "<td>" . $row['first_name_user'] . "</td>";
                echo "<td>" . $row['last_name_user'] . "</td>";
                echo "<td>".$row['login_user']."</td>";
                echo "<td>" . $row['mail_user'] . "</td>";
                echo "<td>" . $row['number_user'] . "</td>";
                echo "<td>" . $row['name_service'] . "</td>";
                echo "<td>" . $row['price_service'] . "</td>";
                echo "<td><a href='php/delete_order.php?id=" . $row['id_order'] . "'>Удаллить</a></td>";
               
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='9'>No orders found</td></tr>";
        }
        ?>
    </table>
</body>
</html>